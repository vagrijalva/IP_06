﻿
    class Laboratorio8
    {
        static void Main(string[] args)
        {
            // Muestra tu nombre y número de carné
            Console.WriteLine("Vinicio Armando Grijalva Escribá  - Carné: 1093723");

            // Solicita al usuario que ingrese una cantidad en quetzales
            Console.Write("Ingrese una cantidad en quetzales (0-999.99): ");
            if (double.TryParse(Console.ReadLine(), out double CEQZ) && CEQZ >= 0 && CEQZ <= 999.99)
            {
                MostrarEquivalencia(CEQZ);
            }
            else
            {
                Console.WriteLine("La cantidad ingresada debe estar en el rango de 0 a 999.99");
            }

            Console.ReadLine();
        }

        static void MostrarEquivalencia(double CEQZ)
        {
            int billete100 = 0, billete50 = 0, billete20 = 0, billete10 = 0, billete5 = 0;
            int moneda1 = 0, moneda25Centavos = 0, moneda1Centavo = 0;

            if (CEQZ >= 100)
            {
                billete100 = (int)(CEQZ / 100);
                CEQZ %= 100;
            }

            if (CEQZ >= 50)
            {
                billete50 = (int)(CEQZ / 50);
                CEQZ %= 50;
            }

            if (CEQZ >= 20)
            {
                billete20 = (int)(CEQZ / 20);
                CEQZ %= 20;
            }

            if (CEQZ >= 10)
            {
                billete10 = (int)(CEQZ / 10);
                CEQZ %= 10;
            }

            if (CEQZ >= 5)
            {
                billete5 = (int)(CEQZ / 5);
                CEQZ %= 5;
            }

            moneda1 = (int)CEQZ;
            CEQZ -= moneda1;

            if (CEQZ >= 0.25)
            {
                moneda25Centavos = (int)(CEQZ / 0.25);
                CEQZ %= 0.25;
            }

            moneda1Centavo = (int)(CEQZ / 0.01);

            // Muestra los resultados
            Console.WriteLine($"{billete100} de Q 100");
            Console.WriteLine($"{billete50} de Q 50");
            Console.WriteLine($"{billete20} de Q 20");
            Console.WriteLine($"{billete10} de Q 10");
            Console.WriteLine($"{billete5} de Q 5");
            Console.WriteLine($"{moneda1} de Q 1");
            Console.WriteLine($"{moneda25Centavos} de 25 centavos");
            Console.WriteLine($"{moneda1Centavo} de 1 centavo");

            Console.ReadKey();
            Console.Clear();
    }
    }

