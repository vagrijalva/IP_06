﻿using System;
class Laboratorio6
{
    static void Main(string[] args)
    {
        //AÑADIR MENSAJE DEL EJERCICIO NO.1
        Console.WriteLine("Ejercicio 1: operaciones aritméticas.");

        double n1;
        double n2;
        double n3;

        // INGRESO DE DOS NÚMEROS
        Console.WriteLine("\n Ingresar un número:");
        n1 = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("\n Ingresar un segundo número:");
        n2 = Convert.ToDouble(Console.ReadLine());

        //OPERAR LOS DOS NÚMEROS

        double sum = n1 + n2;
        double res = n1 - n2;
        double mul = n1 * n2;
        double divi = n1 / n2;
        double mod = n1 % n2;
        int div = (int)(n1 / n2);


        //MOSTRAR EL RESULTADO DE LAS OPERACIONES
        Console.WriteLine("\nRESULTADO SUMA: " + n1 + "+" + n2 + " = " + sum);
        Console.WriteLine("RESULTADO RESTA: " + n1 + "-" + n2 + " = " + res);
        Console.WriteLine("RESULTADO MULTIPLICACIÓN: " + n1 + "x" + n2 + " = " + mul);
        Console.WriteLine("RESULTADO DIVISIÓN: " + n1 + "÷" + n2 + " = " + divi);
        Console.WriteLine("RESULTADO MOD: " + n1 + "%" + n2 + " = " + mod);
        Console.WriteLine("RESULTADO DIV: " + n1 + "÷" + n2 + " = " + div);

        Console.ReadKey();
        Console.Clear();

        //AÑADIR MENSAJE DEL EJERCICIO NO.2
        Console.WriteLine("\nEJERCICIO NO.2 \nOPERACIONES BOOLEANAS");

        //CONDICIONES DE LAS OPERACIONES CON LAS VARIABLES
        bool may = n1 > n2;
        bool men = n1 < n2;
        bool ig = n1 == n2;

        if (may)
        {
            Console.WriteLine(n1 + " es mayor que " + n2);
        }
        else if (men)
        {
            Console.WriteLine(n1 + " es menor que " + n2);
        }
        else if (ig)
        {
            Console.WriteLine(n1 + " es igual que " + n2);
        }

        Console.ReadKey();
        Console.Clear();

        //AÑADIR MENSAJE DEL EJERCICIO NO.3
        Console.WriteLine("\nEJERCICIO NO.3 \nJERARQUÍA DE OPERACIONES");
        
        //INGRESAR UN TERCER VALOR NUMERICO
        Console.WriteLine("\n ingresar un tercer número:");
        n3 = Convert.ToDouble(Console.ReadLine());

        //OPERACIONES PARA LA JERARQUIA DE OPERACIONES
        double res1 = n1 * n2 + n3;
        double res2 = n1 * (n2 + n3);
        double res3 = n1 / n2 * n3;
        double res4 = (3 * n1 + 2 * n2) / (n3 * n3);

        //MUESTRA DEL DESARROLLO DE OPERACIONES
        Console.WriteLine("Resultado 1: " + n1 + "*" + n2 + "+" + n3 + " = " + res1);
        Console.WriteLine("Resultado 2: " + n1 + "*" + "(" + n2 + "+" + n3 + ")" + " = " + res2);
        Console.WriteLine("Resultado 3: " + n1 + "/" + n2 + "*" + n3 + " = " + res3);
        Console.WriteLine("Resultado 4: " + "(" + "3" + "*" + n1 + "+" + "2" + "*" + n2 + ")" + "/" + "(" + n3 + "^2)" + " = " + res4);

        Console.ReadKey();
        Console.Clear();

        //AÑADIR MENSAJE DEL EJERCICIO NO.4
        Console.WriteLine("\nEJERCICIO NO.4 \nEXPRESION CUADRÁTICA");
        double a;
        double b;
        double c;

        // INGRESO DE LOS VALORES
        Console.WriteLine("\n Ingresar un valor numérico para a:");
        a = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("\n Ingresar un valor numérico para b:");
        b = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine("\n Ingresar un valor numérico para c:");
        c = Convert.ToDouble(Console.ReadLine());


        //CALCULAR LA ECUAÇION CUADRATICA
        if (a != 0 && (Math.Pow(b, 2) - 4 * a * c) >= 0)
        {
            double discriminante = Math.Pow(b, 2) - 4 * a * c;
            double x1 = (-b + Math.Sqrt(discriminante)) / (2 * a);
            double x2 = (-b - Math.Sqrt(discriminante)) / (2 * a);

            Console.WriteLine("Resultados:");
            Console.WriteLine($"x1 = {x1}");
            Console.WriteLine($"x2 = {x2}");
        }
        else
        {
            Console.WriteLine("Error: Las condiciones no se cumplen. Asegúrese de que 'a' no sea igual a 0 y que b^2 - 4ac sea mayor o igual a 0.");
        }

        Console.ReadKey();
        Console.Clear();
    }
}
