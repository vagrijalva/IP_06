﻿class claseMenu
{
    static void Main(string[] args)
    {
        Console.WriteLine("Mi programa, Gestion de inventario y manufactura de una empresa automotriz");
        Console.WriteLine();
        Console.WriteLine("Selecione el caracter del vehiculo");
        Console.WriteLine("Menu principal");
        Console.WriteLine("1. Vehiculo personal ");
        Console.WriteLine("2. Vehiculo de carga ");
        string opcion;
        opcion = Console.ReadLine();

        if (opcion == "Vehículo personal")
        {
            Console.WriteLine(" Usted seleccionó la opción " + opcion + " Vehículo personal");
        }
        else
        {
            Console.WriteLine(" Usted seleccionó la opción " + opcion + " Vehículo de carga");
        }
        Console.ReadKey();

    }

    
}