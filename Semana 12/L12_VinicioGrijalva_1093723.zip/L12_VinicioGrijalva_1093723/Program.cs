﻿using System;

class L12_VinicioGrijalva_1093723
{
    static void Main(string[] args)
    {
        // Declarar un arreglo unidimensional de 10 posiciones
        double[] numeros = new double[10];

        Console.WriteLine("Ingrese 10 números a su elección");

        // Pedir al usuario ingresar 10 números y guardarlos en el arreglo
        for (int i = 0; i < 10; i++)
        {
            Console.WriteLine($"Ingrese el valor para el número en la posición {i + 1}");
            numeros[i] = Convert.ToDouble(Console.ReadLine());
        }

        // Encontrar el número más grande ingresado por el usuario
        double mayor = numeros[0];
        for (int x = 1; x < 10; x++)
        {
            if (numeros[x] > mayor)
            {
                mayor = numeros[x];
            }
        }

        // Encontrar el número más pequeño ingresado por el usuario
        double menor = numeros[0];
        for (int c = 1; c < 10; c++)
        {
            if (numeros[c] < menor)
            {
                menor = numeros[c];
            }
        }

        // Calcular la suma total de todos los números ingresados
        double suma = 0;
        for (int c = 0; c < 10; c++)
        {
            suma += numeros[c];
        }

        // Calcular el promedio de los números ingresados
        double promedio = suma / 10;

        // Encontrar y mostrar la suma de posiciones pares e impares
        double sumapares = 0;
        double sumaimpares = 0;

        for (int c = 0; c < 10; c++)
        {
            if (c % 2 == 0)
            {
                // Posición par
                sumapares += numeros[c];
            }
            else
            {
                // Posición impar
                sumaimpares += numeros[c];
            }
        }

        // Mostrar los resultados
        Console.WriteLine($"El número más grande es: {mayor}\n");
        Console.WriteLine($"El número más pequeño es: {menor}\n");
        Console.WriteLine($"La suma de los valores es: {suma} \n");

        Console.WriteLine("Números desde la posición 0 a la 9");
        for (int i = 0; i < 10; i++)
        {
            Console.WriteLine($"El número ingresado en la posición {i + 1} es: {numeros[i]}");
        }

        Console.WriteLine("Números desde la posición 9 a la 0");
        for (int i = 9; i >= 0; i--)
        {
            Console.WriteLine($"El número ingresado en la posición {i} es: {numeros[i]}");
        }

        Console.WriteLine($"El promedio de los números ingresados es: {promedio}");

        Console.WriteLine($"La suma de los números en las posiciones pares es: {sumapares}");
        Console.WriteLine($"La suma de los números en las posiciones impares es: {sumaimpares}");

        Console.ReadKey();
    }
}
