﻿using System.Diagnostics.Tracing;

class Laboratorio7
{
    static void Main(string[] arg)
    {
        //Ejercicio No.1
        int Numero1 = 0;
        Console.WriteLine("Ejercicio 1");
        Console.WriteLine("Dado un número entero, como dato, determine si el mismo es positivo, negativo o cero.");
        Console.WriteLine("\nIngresa un numero entero");
        Numero1 = Int32.Parse(Console.ReadLine());

        if (Numero1 > 0)
        {
            Console.WriteLine("\nEl numero es positivo ");
        }
        else if (0 > Numero1)
        {
            Console.WriteLine("\nEl numero es negativo ");
        }
        else if (0==Numero1)
        {
            Console.WriteLine("\nEl numero es igual a cero");
        }
        else
        {
            Console.WriteLine("\n Valor invalido");
        }
        Console.ReadKey();

        //Ejercicio 2

        int Numero2 = 0;
        Console.WriteLine("Ejercicio 2");
        Console.WriteLine("Instrucciones: el programa que indique el día de la semana correspondiente al número, siendo 1 el dia lunes y 7 el domingo).");
        Console.WriteLine("\nIngresa un numero entero");
        Numero2 = Int32.Parse(Console.ReadLine());
        
      

        if (Numero2 == 0)
        {
            Console.WriteLine("\n Error: El número a ingresar debe estar contenido entre 1 y 7 ");
        }
        else if (Numero2 > 7)
        {
            Console.WriteLine("\n El dia ingresado debe estra contendio entre 1 y 7");
        }
        else
        {
            switch (Numero2)
            {
                case 1:
                    Console.WriteLine("\n El dia ingresado es lunes ");
                    break;

                case 2:
                    Console.WriteLine("\n El dia ingresado es martes ");
                    break;

                case 3:
                    Console.WriteLine("\n El dia ingresado es miercoles ");
                    break;

                case 4:
                    Console.WriteLine("\n El dia ingresado es jueves ");
                    break;

                case 5:
                    Console.WriteLine("\n El dia ingresado es viernes ");
                    break;

                case 6:
                    Console.WriteLine("\n El dia ingresado es sabado ");
                    break;

                case 7:
                    Console.WriteLine("\n El dia ingresado es domingo ");
                    break;
            }
        }
        Console.ReadKey();
        
    }

}
