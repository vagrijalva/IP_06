﻿class Laboratorio_9
{
    public static string sValor;
    public static float Valor, MontoFinal, codDes, TotalConDescuento;

    public static void Main(string[] args)
    {
        for (int j = 0; j >= 0; j++)
        {
            int op = 0;
            Console.WriteLine("Ejercicio - Laboratorio 9");
            Console.WriteLine("Ingrese el valor de su compra");
            sValor = Console.ReadLine();

            while (!float.TryParse(sValor, out Valor))
            {
                Console.WriteLine("Ingrese un valor válido, ejemplo 0.00");
                sValor = Console.ReadLine();
            }

            for (int i = 0; i >= 0; i++)
            {
                try
                {
                    Console.WriteLine("¿Posee código de descuento?");
                    Console.WriteLine("Ingrese '1' en caso de tener código de descuento.");
                    Console.WriteLine("Ingrese '2' en caso de no tener código de descuento.");
                    op = Int32.Parse(Console.ReadLine());

                    if (op == 1)
                    {
                        Console.WriteLine("\nIngrese su código de descuento");
                        Console.ReadLine();
                    }

                    CalcularDescuento();

                    if (op == 1)
                    {
                        codDes = (MontoFinal * 5) / 100;
                        TotalConDescuento = MontoFinal - codDes;
                        Console.WriteLine($"\nSu monto al pagar final es {TotalConDescuento}");
                    }
                    else if (op == 2)
                    {
                        Console.WriteLine($"\nSu monto al pagar final es {MontoFinal}");
                    }

                    break;
                }
                catch (Exception)
                {
                    Console.WriteLine("Ingrese una opción válida");
                }
            }

            Console.ReadKey();
            Console.Clear();
        }
    }

    public static void CalcularDescuento()
    {
        float descuento = 0;
        float total = 0;

        if (Valor < 400)
        {
            MontoFinal = Valor;
        }
        else if (Valor < 1000)
        {
            descuento = (Valor * 7) / 100;
            total = Valor - descuento;
            MontoFinal = total;
        }
        else if (Valor < 5000)
        {
            descuento = (Valor * 10) / 100;
            total = Valor - descuento;
            MontoFinal = total;
        }
        else if (Valor < 15000)
        {
            descuento = (Valor * 15) / 100;
            total = Valor - descuento;
            MontoFinal = total;
        }
        else
        {
            descuento = (Valor * 25) / 100;
            total = Valor - descuento;
            MontoFinal = total;
        }
        Console.ReadKey();
    }
}
