﻿

class program
{
    static void Main(string[] args)

    {
        Console.WriteLine("Ingrese su nombre:");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("soy" + Nombre );

        /*Esto es un ejemplo de comentario*/
        //Otros comentarios 

        Console.WriteLine("Hola Mundo");
        Console.WriteLine("Soy" + Nombre );
        Console.ReadKey();

    } 

}

     
